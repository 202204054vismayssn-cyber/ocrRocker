import os
import shutil
from pathlib import Path
from tempfile import NamedTemporaryFile

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# Import OCR processors
try:
    from pdf_router import run_pdf_batch
    from invoice_extraction_colab import run_batch
except ImportError as e:
    print(f"Warning: Ensure this is run from the directory containing the modules. {e}")

app = FastAPI(title="Invoice OCR API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

OUTPUT_DIR = Path("output")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Note on Qwen fallback: Skipped for now per instructions, might add in the future.

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Invoice OCR Upload</title>
    <style>
        body { font-family: sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; }
        .upload-container { border: 2px dashed #ccc; padding: 40px; text-align: center; border-radius: 8px; }
        #result { margin-top: 20px; background: #f4f4f4; padding: 15px; border-radius: 5px; white-space: pre-wrap; font-family: monospace; }
        button { padding: 10px 20px; font-size: 16px; cursor: pointer; background: #007bff; color: white; border: none; border-radius: 4px; }
        button:hover { background: #0056b3; }
        .spinner { display: none; margin-top: 15px; }
    </style>
</head>
<body>
    <h2>Upload Document for Invoice OCR</h2>
    <div class="upload-container">
        <input type="file" id="fileInput" accept=".pdf,.jpg,.jpeg,.png,.tif,.tiff">
        <br><br>
        <button onclick="uploadFile()">Upload & Process</button>
        <div id="spinner" class="spinner">Processing... Please wait.</div>
    </div>

    <div id="result"></div>

    <script>
        async function uploadFile() {
            const fileInput = document.getElementById('fileInput');
            if (fileInput.files.length === 0) {
                alert("Please select a file first.");
                return;
            }

            const file = fileInput.files[0];
            const formData = new FormData();
            formData.append("file", file);

            const resultDiv = document.getElementById('result');
            const spinner = document.getElementById('spinner');

            resultDiv.innerText = "";
            spinner.style.display = "block";

            try {
                const response = await fetch('/upload', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();
                resultDiv.innerText = JSON.stringify(data, null, 2);
            } catch (error) {
                resultDiv.innerText = "Error processing file: " + error.message;
            } finally {
                spinner.style.display = "none";
            }
        }
    </script>
</body>
</html>
"""


def _clean_result(result: dict) -> dict:
    """Return only the fields and needs_review sections for user-facing output."""
    return {
        "fields": result.get("fields"),
        "needs_review": result.get("needs_review"),
        "missing_required": result.get("missing_required"),
    }


@app.get("/", response_class=HTMLResponse)
async def get_index():
    return HTML_TEMPLATE


@app.post("/upload")
async def upload_document(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file selected")

    ext = Path(file.filename).suffix.lower()

    # Save the uploaded file temporarily
    with NamedTemporaryFile(delete=False, suffix=ext) as tmp:
        shutil.copyfileobj(file.file, tmp)
        temp_path = tmp.name

    try:
        if ext == '.pdf':
            # Native & mixed PDF handling through pdf router
            # Skip Qwen semantic fallback as instructed (for now)
            results = run_pdf_batch(
                [temp_path],
                output_dir=str(OUTPUT_DIR),
                export_xml=True
            )
        elif ext in ['.jpg', '.jpeg', '.png', '.tif', '.tiff']:
            # Non-native image files go through invoice_extraction_colab
            results = run_batch(
                [temp_path],
                export_xml=True
            )
            import json
            batch_output = OUTPUT_DIR / f"image_result_{Path(temp_path).stem}.json"
            batch_output.write_text(json.dumps(results, indent=2), encoding="utf-8")
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        # Clean up temporary input file
        if os.path.exists(temp_path):
            os.remove(temp_path)

    # Only expose fields and needs_review to users — all internal
    # diagnostics (timing, routing metadata, etc.) stay on disk only.
    clean_results = [_clean_result(r) for r in results]

    return JSONResponse(content={
        "status": "success",
        "results": clean_results
    })


if __name__ == "__main__":
    uvicorn.run("app2:app", host="127.0.0.1", port=8000, reload=True)
