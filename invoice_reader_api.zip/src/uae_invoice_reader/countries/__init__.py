"""Independent country invoice modules."""
