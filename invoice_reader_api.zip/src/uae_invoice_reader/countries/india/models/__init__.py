"""India invoice domain models."""

