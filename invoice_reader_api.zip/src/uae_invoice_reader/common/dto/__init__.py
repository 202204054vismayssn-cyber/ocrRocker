"""Shared API contracts."""
