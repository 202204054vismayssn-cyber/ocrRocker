"""Country-neutral document models."""
