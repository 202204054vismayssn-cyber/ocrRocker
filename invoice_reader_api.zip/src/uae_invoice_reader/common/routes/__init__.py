"""Shared system routes."""
